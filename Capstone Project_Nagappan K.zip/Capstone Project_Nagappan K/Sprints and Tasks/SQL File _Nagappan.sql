use football_data;

# Player Profile and Market Value:- What is the average market value of players grouped by their position?
SELECT position_x, AVG(market_value_in_eur) AS avg_market_value FROM football_db
GROUP BY position_x
ORDER BY avg_market_value DESC;

# Substitution Patterns:- What is the average substitution minute for each team?
SELECT home_club_name, AVG(minute) AS avg_substitution_minute FROM football_db
WHERE minute IS NOT NULL
GROUP BY home_club_name
ORDER BY avg_substitution_minute;